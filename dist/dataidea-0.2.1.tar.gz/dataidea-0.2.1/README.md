This is a tool to simplify data analysis
