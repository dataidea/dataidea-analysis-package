import os
import pandas as pd

def load(name:str=None):
    '''
    Easily load datasets that are inbuit in DATAIDEA

    parameters:\n
    name: this is the name of the dataset, eg demo, fpl, music, titanic etc
    '''
    package_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(package_dir, 'datasets', f'{name}.csv')
    return pd.read_csv(data_path)